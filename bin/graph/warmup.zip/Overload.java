package graph;

public @interface Overload {

}
